from distutils.core import setup

setup(name='Python_dev',
      description='Python development core',
      packages=['dev', 'dev.python'],
     )
